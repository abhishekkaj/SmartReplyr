<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SmartReplyr_Webhook {

    /**
     * Send lead data to configured webhook URL with dynamic field mapping.
     */
    public function send( $lead ) {
        return smartreplyr_safe_execute(function() use ($lead) {
            $webhook_url = SmartReplyr_DB::get_setting( 'webhook_url', '' );
            if ( empty( $webhook_url ) ) {
                return false;
            }

            // Get field mapping
            $mapping_json = SmartReplyr_DB::get_setting( 'field_mapping', '{}' );
            $mapping      = json_decode( $mapping_json, true ) ?: array();

            // Build payload with mapping
            $payload = $this->build_payload( $lead, $mapping );

            // Send POST request
            $response = wp_remote_post( $webhook_url, array(
                'timeout'     => 15,
                'sslverify'   => false,
                'user-agent'  => 'SmartReplyr-Webhook/1.0',
                'headers'     => array(
                    'Content-Type' => 'application/json',
                ),
                'body'        => wp_json_encode( $payload ),
            ) );

            if ( is_wp_error( $response ) ) {
                $err_msg = $response->get_error_message();
                SmartReplyr_DB::add_log('webhook', 'external', 'failed', "Webhook cURL Error: " . $err_msg, array('lead_id' => $lead['id'] ?? 0));
                error_log( 'SmartReplyr Webhook Error: ' . $err_msg );
                return false;
            }

            $code = wp_remote_retrieve_response_code( $response );
            if ( $code < 200 || $code >= 300 ) {
                $body_resp = wp_remote_retrieve_body( $response );
                SmartReplyr_DB::add_log('webhook', 'external', 'failed', "Webhook HTTP $code: " . $body_resp, array('lead_id' => $lead['id'] ?? 0));
                error_log( 'SmartReplyr Webhook HTTP ' . $code . ': ' . $body_resp );
                return false;
            }

            return true;
        });
    }

    /**
     * Build payload with dynamic field mapping.
     * Iterates through all available lead data and maps keys to the user-defined external names.
     */
    private function build_payload( $lead, $mapping ) {
        $payload = array();

        // 1. Map all database columns to external keys if defined in mapping
        // Internal keys examples: name, phone, email, course_interest, utm_source, page_url etc.
        foreach ( $lead as $key => $value ) {
            $external_key = ! empty( $mapping[ $key ] ) ? $mapping[ $key ] : $key;
            $payload[ $external_key ] = $value;
        }

        // 2. Ensure system metadata is always present (unless overridden by mapping)
        if ( ! isset( $payload['source'] ) ) {
            $payload['source'] = 'smartreplyr-ai';
        }
        if ( ! isset( $payload['site_url'] ) ) {
            $payload['site_url'] = get_site_url();
        }

        // 3. Structured UTM support (legacy support for CRM that expects nested 'utm' object)
        $utm = array();
        foreach ( array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' ) as $utm_key ) {
            if ( ! empty( $lead[ $utm_key ] ) ) {
                $utm[ $utm_key ] = $lead[ $utm_key ];
            }
        }
        if ( ! empty( $utm ) && ! isset( $payload['utm'] ) ) {
            $payload['utm'] = $utm;
        }

        return $payload;
    }
}
